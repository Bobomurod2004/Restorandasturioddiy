import asyncio
import sqlite3
from aiogram import Dispatcher, Bot
from aiogram.filters import Command
from aiogram.types import Message,  ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, \
    InlineKeyboardButton, CallbackQuery

bot = Bot(token='7559841137:AAGvh5sD4c-ib-jUbRT_KD2GA0rqsmX4gB4')
dp = Dispatcher()
chat_id = "@bobomurodbeckend"
chat_idbot = "@millenium_ielts1_bot"
user_data={}



conn = sqlite3.connect("users.db")
cursor = conn.cursor()

# Foydalanuvchi ma'lumotlari jadvali
cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    phone_number TEXT,
    points INTEGER DEFAULT 0,
    invited_by INTEGER
)
""")
conn.commit()

@dp.message(Command("start"))
async def catch_command(message: Message):
    user_id = message.from_user.id
    args = message.text.split()

    invited_by = None
    if len(args) > 1 and args[1].isdigit():
        invited_by = int(args[1])

    # Agar foydalanuvchi oldin bazada bo'lmasa, qo‘shamiz
    cursor.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    user = cursor.fetchone()

    if not user:
        cursor.execute("INSERT INTO users (user_id, phone_number, invited_by, points) VALUES (?, ?, ?, ?)",
                       (user_id, None, invited_by, 0))
        conn.commit()


    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📲Telefon raqamni yuborish",request_contact=True)],
        ],
        resize_keyboard=True,one_time_keyboard=True
    )
    await message.answer("📌 Iltimos, telefon raqamingizni yuboring:", reply_markup=keyboard)


@dp.message(lambda message: message.contact)
async def get_contact(message: Message):
    user_id = message.from_user.id
    contact_number = message.contact.phone_number

    cursor.execute("SELECT invited_by FROM users WHERE user_id=?", (user_id,))
    user = cursor.fetchone()

    if user:
        invited_by = user[0]
    else:
        invited_by = None

    # Foydalanuvchi raqamini yangilash
    cursor.execute("UPDATE users SET phone_number = ? WHERE user_id = ?", (contact_number, user_id))
    conn.commit()

    # 🔥 Yangi kod: Agar foydalanuvchi birinchi marta kirayotgan bo‘lsa, points qo‘shamiz
    if invited_by is not None:
        cursor.execute("SELECT COUNT(*) FROM users WHERE invited_by=? AND user_id=?", (invited_by, user_id))
        already_counted = cursor.fetchone()[0]

        if already_counted == 0:  # 🔹 Agar bu ID bo‘yicha points qo‘shilmagan bo‘lsa
            cursor.execute("UPDATE users SET points = points + 1 WHERE user_id=?", (invited_by,))
            conn.commit()

    keybord = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📝Kanalga qo'shilish",url=f"https://t.me/{chat_id.strip('@')}")],
            [InlineKeyboardButton(text="✅Obunani tekshirish",callback_data="tekshirish")]
        ]
    )
    await message.answer("📌 Avval kanalga obuna bo‘ling va \n"
                         "Obunani tekshirish' tugmasini bosing:",reply_markup=keybord)


@dp.callback_query(lambda callback: callback.data == "tekshirish")
async def check_subscription(callback: CallbackQuery):
    user_id = callback.from_user.id
    user_link = f"https://t.me/{chat_idbot.strip('@')}?start={user_id}"
    chat_member = await bot.get_chat_member(chat_id, user_id)
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📊 Mening hisobim")],
            [KeyboardButton(text="🔗Referal Link")]
        ],
        resize_keyboard=True
    )
    await callback.message.answer(text=chat_member.status, reply_markup=keyboard)

    if chat_member.status in ["member", "administrator", "creator"]:
        await callback.message.answer("🎉 Siz kanalga a'zo bo'dingiz!\n\n"
                                      "🔗Bu sizning referal linkingiz\n"
                                      f"🟦{user_link}\n"
                                      "👥 3 ta do‘stingizni taklif qilib, bepul marafonga ega bo‘ling!")
    else:
        await callback.message.answer("❌ Siz hali kanalga a'zo bo‘lmadingiz! Iltimos, kanalga obuna bo‘ling.")


@dp.message(lambda message: message.text == "📊 Mening hisobim")
async def send_link(message: Message):
    user_id = message.from_user.id
    phone_nuber = user_data.get(user_id,{}).get("phone_number","mavjud emas")
    cursor.execute("SELECT phone_number, points FROM users WHERE user_id=?", (user_id,))
    user = cursor.fetchone()
    if user:
        phone_number, points = user
    else:
        phone_number, points = "Mavjud emas", 0
    await message.answer  (f"🎯 Your Points:{points}\n"
                          f"💬 Your ID:{user_id}\n"
                          f"👥 Friends Invited:{points} people\n"
                          f"📱 Account Number:{phone_nuber}")

@dp.message(lambda message: message.text == "🔗Referal Link")
async def send_link(message: Message):
    user_id = message.from_user.id
    user_link = f"https://t.me/{chat_idbot.strip('@')}?start={user_id}"
    await message.answer(f"👤{message.from_user.full_name} ,bu yerda sizning referal linkingiz \n\n"
                         f"🔗{user_link}"
                         )

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
